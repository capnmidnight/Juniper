//#define DEBUG_TNTD

using UnityEngine;
using Unity.Mathematics;
using E7.Native;

/// <summary>
/// Extension idea : 
/// - Storing all movement in a set, not just replaced with begin-end.
/// This allows you to calculate the true length (sum of all sections in a set if they are curved)
/// - Make use of Android's touch precision.
/// </summary>
public struct TrackedNativeTouchData
{
    private const int undefinedTouchId = -1;
    private const int defaultState = default;

    public TrackedNativeTouchData(ref NativeTouchData ntd, int runningTouchId, int screenHeight)
    {
        position = new int2(ntd.IntegerX, screenHeight - ntd.IntegerY);
        setPosition = position;
        movementVector = int2.zero;
        latestPhase = TouchPhase.Began;
        setPhase = TouchPhase.Began;
        state = defaultState;
        timestamp = ntd.Timestamp;
        lateTimestamp = ntd.Timestamp;
        setState = SetState.SetInProgressFirstSet;
        this.runningTouchId = runningTouchId;
        cumulativeSquaredMagnitude = 0;
    }

    /// <summary>
    /// Just in case you want to interop Unity's normal touch with this.
    /// </summary>
    public TrackedNativeTouchData(ref Touch t, int runningTouchId)
    {
        position = new int2(t.position);
        setPosition = position;
        movementVector = new int2(t.deltaPosition);
        latestPhase = t.phase;
        setPhase = t.phase;
        state = defaultState;
        timestamp = -1;
        lateTimestamp = -1;
        setState = SetState.SetInProgressFirstSet;
        this.runningTouchId = runningTouchId;
        cumulativeSquaredMagnitude = math.lengthsq(movementVector);
    }

    /// <summary>
    /// We must have already determined that the touch is the right previous touch to the `ntd` argument.
    /// It will mutate its data. This can be progressed into Ended/Canceled state.
    /// </summary>
    public bool Progress(ref NativeTouchData ntd, int screenHeight)
    {
        var newPosition = new int2(ntd.IntegerX, screenHeight - ntd.IntegerY);
        var oldPosition = position;
        bool progressToEnded = false;

        if (ntd.Phase == TouchPhase.Ended || ntd.Phase == TouchPhase.Canceled) 
        {
            //We have to trust the phase if it is one of these two.
            //Since we couldn't tell if the touch has ended or canceled from coordinate data alone.
            latestPhase = ntd.Phase;
            progressToEnded = true;
        }
        else
        {
            //Android's Moved might means Stationary, iOS's Stationary sometimes has different coordinate as well.
            //So in summary we cannot trust `ntd.Phase`
            latestPhase = (position.Equals(newPosition)) ? TouchPhase.Stationary : TouchPhase.Moved;
        }

        position = newPosition;

        switch(setState)
        {
            case SetState.SetInProgress:
            {
                setState = latestPhase == TouchPhase.Moved ? SetState.SetInProgressMoved : SetState.SetInProgress;
                setPhase = latestPhase;
                break;
            }
            case SetState.SetInProgressMoved:
            {
                //If the set already conained any moved event, the set phase cannot change back to stationary.
                switch(latestPhase)
                {
                    case TouchPhase.Ended:
                    case TouchPhase.Canceled:
                    {
                        setPhase = latestPhase;
                        break;
                    }
                }

                break;
            }
            case SetState.SetInProgressFirstSet:
            {
                //First set's setPhase will stick to Began.
                //First set cannot change to SetInProgressMoved on any move event.
                break;
            }
            case SetState.SetEnded:
            {
                //Make it so that when beginning a new set while dragging, there should be no instance that
                //the movement vector is 0,0. It is continued from the latest touch.
                //On iOS the previous position field does not play a role here, since it is the same as `oldPosition`.
                setPosition = oldPosition;

#if DEBUG_TNTD
                Debug.Log($"New set, setPosition now {setPosition}");
#endif
                timestamp = ntd.Timestamp;
                lateTimestamp = ntd.Timestamp;
                setState = latestPhase == TouchPhase.Moved ? SetState.SetInProgressMoved : SetState.SetInProgress;
                setPhase = latestPhase; //If set ended, this movement's state become the phase
                cumulativeSquaredMagnitude = 0;
                break;
            }
        }

        //If not beginning a new set, a movement vector will be measured from the remembered set position as a straight line.
        movementVector = newPosition - setPosition;
        cumulativeSquaredMagnitude += math.lengthsq(movementVector);

#if DEBUG_TNTD
        Debug.Log($"Movement vector {movementVector} = {newPosition} - {setPosition}");
#endif

        lateTimestamp = ntd.Timestamp;

        return progressToEnded;
    }

    /// <summary>
    /// - If the touch hasn't been progressed at all in a set it will be forced to Stationary.
    /// - Make the next progress put a new anchor for the touch's movement vector.
    /// </summary>
    public void EndSet()
    {
        //If the state is SetEnded it is either that after the last EndSet a touch hasn't been progressed at all,
        //or ending a set immediately after instantiating. (In that case we want to preserve the Began phase once.)

#if DEBUG_TNTD
        Debug.Log($"Ending set of {this}");
#endif
        latestPhase = setState == SetState.SetEnded ? TouchPhase.Stationary : latestPhase;
        //Ending a set must be able to change the kept-Began setPhase.
        setPhase = setState == SetState.SetEnded ? TouchPhase.Stationary : setPhase;
        setState = SetState.SetEnded;
    }

    private enum SetState
    {
        SetInProgressFirstSet = 0,
        SetInProgress = 1,
        SetInProgressMoved = 2,
        SetEnded = 3,
    }

    private SetState setState;

    /// <summary>
    /// The position at the start of the "set", used to calculate the movement vector.
    /// </summary>
    private int2 setPosition;

    /// <summary>
    /// The Y axis has been converted to Unity's convention by `NativeTouchTracker`'s constructor screenHeight.
    /// </summary>
    public int2 position { get; private set; }

    /// <summary>
    /// A vector point from the beginning to the end of the current "set".
    /// If there are multiple movements (such as curved movement) they will be turned into just a straight line.
    /// This is similar to Unity's simplification.
    /// When the phase is Stationary, the movementVector will not be zero out but will remains at the last movement.
    /// </summary>
    public int2 movementVector { get; private set; }

    /// <summary>
    /// If a set contains multiple linked movements, this is the cumulative squared magnitude.
    /// This should be higher than squared magnitude of `movementVector` since that was simplified as a
    /// vector of the first to the last point of a set. This magnitude allows finer movement details than Unity's `Input.touches`.
    /// Uses `Unity.Mathmatics`'s `lengthsq` (a dot product, 2 multiplications)
    /// </summary>
    public float cumulativeSquaredMagnitude { get; private set; }

    /// <summary>
    /// Interpreted touch phase. It is the latest phase recorded in a set.
    /// When the phase is Stationary, the movementVector will not be zero out but will remains at the last movement.
    /// When the phase is Stationary, the timestamp will be the last one as well.
    /// (Native side does not report "still" touch technically, there is no such thing as stationary timestamp.)
    /// </summary>
    public TouchPhase latestPhase { get; private set; }

    /// <summary>
    /// Interpreted touch phase. Depending on recorded movement sequence in a set this can be :
    /// 
    /// `TouchPhase.Began` : If the first track of this set is `Began`, regardless of the latest phase.
    /// It is possible to have this while the latest phase is `Ended` or `Cancelled`.
    /// `TouchPhase.Moved` : If the first track of this set is not `Began`, the final track is not `Ended` or `Cancelled`, and there is at least one `Moved` phase in the set. (Used to detect a moved set, but remaining `Stationary` at the last movement.)
    /// `TouchPhase.Stationary` : The entire set does not move yet.
    /// All other phases : the same as `phase` property.
    /// This is more like Unity's Touch's phase. But this tracker's `Began` `setPhase` can contains multiple movements leading up to the latest point.
    /// </summary>
    public TouchPhase setPhase { get; private set; }

    /// <summary>
    /// Interpreted touch ID.
    /// The number will be the same for the same finger.
    /// The number keeps increasing for a new finger, unlike Unity which reuse old ID.
    /// </summary>
    public int runningTouchId { get; private set; }

    /// <summary>
    /// 0 is the default state. You can store any state to go with the touch.
    /// Currently unused...
    /// </summary>
    public int state { get; private set; }

    /// <summary>
    /// If a set consist of multiple movements it is the time of the first one.
    /// When the phase is Stationary, the timestamp will be the last one as well.
    /// (Native side does not report "still" touch technically, there is no such thing as stationary timestamp.)
    /// </summary>
    public double timestamp { get; private set; }

    /// <summary>
    /// If a set consist of multiple movements it is the time of the last one.
    /// When the phase is Stationary, the timestamp will be the last one as well.
    /// (Native side does not report "still" touch technically, there is no such thing as stationary timestamp.)
    /// </summary>
    public double lateTimestamp { get; private set; }

    public override string ToString() => $"Pos {position} Movement {movementVector} SqMag {cumulativeSquaredMagnitude} Phase {latestPhase}/{setPhase} ID {runningTouchId} Timestamp {timestamp} LateTimestamp {lateTimestamp}";
}
