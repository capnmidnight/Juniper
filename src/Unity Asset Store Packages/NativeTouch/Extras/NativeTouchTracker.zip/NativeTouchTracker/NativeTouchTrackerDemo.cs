﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Text;
using Unity.Collections;
using E7.Native;

public class NativeTouchTrackerDemo : MonoBehaviour {

    public Text debugText;
	private NativeTouchTracker ntt;
	private StringBuilder sb = new StringBuilder();
	private static Queue<NativeTouchData> touchQueue = new Queue<NativeTouchData>();

    void Awake()
    {
		//Y coordinate will be wrong if you rotate the screen, it is cached only once at start.
		//This is completely fine with most games since not many games can morph between horizontal and vertical view.

		ntt = new NativeTouchTracker(NativeTouch.RealScreenResolution().y, Allocator.Persistent);
		NativeTouch.RegisterCallback(NativeTouchCallback);
		NativeTouch.Start();
    }

	void OnDestroy()
	{
		ntt.Dispose();
	}

	static void NativeTouchCallback(NativeTouchData ntd)
	{
		//We need to be careful with Android because this will be on a different thread than the Update
		lock(touchQueue)
		{
			//Debug.Log($"Enqueuing {ntd}");
			touchQueue.Enqueue(ntd);
		}
	}

    void Update()
    {
		//Debug.Log($"Update");
		//We need to be careful with Android because this will be on a different thread than the callback
		lock(touchQueue)
		{
			while (touchQueue.Count > 0)
			{
				NativeTouchData ntd = touchQueue.Dequeue();
				ntt.Track(ref ntd);
			}
		}
		ntt.EndSet();

		sb.Clear();
        for (int i = 0; i < ntt.Touches.Length; i++)
		{
			sb.AppendLine(ntt.Touches[i].ToString());
		}
		debugText.text = sb.ToString();
    }

	void OnApplicationPause(bool pause)
	{
		if(!pause)
		{
			//Debug.Log($"Unpause panic");
			lock(touchQueue)
			{
				touchQueue.Clear();
				ntt.Panic();
			}
		}
	}
}
