﻿//Uncomment this to debug native shenanigans that might happen
//#define DEBUG_POINT_TRACKER

using UnityEngine;
using Unity.Mathematics;
using Unity.Collections;
using Unity.Jobs;
using E7.Native;

namespace E7.Native
{
    /// <summary>
    /// An example of how to "interpret" native touches from the Native Touch plugin.
    /// Unity's `Input.Touches` is one such interpretation, this is my own which works with C# Jobs and Burst compiler.
    /// You can base it for your own touch processing layer.
    /// How to use it : 
    /// 
    /// 1. Receive and store touches from an input source as you like.
    /// 
    /// 2. When you have a chance to run logic, call `Track` and feed touches in sequence.
    /// All touches you feed in this moment are considered to be in the same "set". What can a set do?
    /// - Computed movement vector will accumulate as long as you haven't end the set yet.
    /// (This is because in native input, you might get multiple movements per frame)
    /// - There are 2 timestamps stored in the tracked touch. The normal timestamp is the time of the first touch in the set.
    /// The `lateTimestamp` is from the last touch in the set. This allows you, for example, in a series of very quick curved drag
    /// you can use the latest position while still at the same time use the timestamp from the first bit of the movement.
    /// 
    /// 3. Call `EndSet` to summarize the input.
    /// - All currently down touches that did not change its position will get Stationary phase at this point.
    /// - All touches will be prepared for a new set. The next `Track` will reset the movement accumulation per set.
    /// - Clear out all previous Ended and Cancelled touches.
    /// 
    /// 4. Use the touches in the same way as `Input.touches`, but here its `.Touches`.
    /// </summary>
    public struct NativeTouchTracker : System.IDisposable
    {
        //Everything needs to be a native container so we can copy it to jobs without copying values, still linking to main thread.

        /// <summary>
        /// All in this list are valid touches. It is safe to iterate. Touches in this list :
        /// - Possible states : Began Moved Stationary Ended Cancelled.
        /// - Touches with Ended or Cancelled state also implies Stationary or Moved, since they can have a movement or not leading to that state.
        /// - On calling `EndSet` old preserved Ended and Cancelled state will be cleared out of this list.
        /// - You infer the Ended state yourself by comparing if a particular touch is not here anymore but previously exists.
        /// - If Stationary, the movement vector is undefined but its value is the latest movement before coming to stationary.
        /// - If Stationary, timestamp is also frozen to the latest time. It is not updated.
        /// </summary>
#if UNITY_ANDROID
        public NativeHashMapList<int, TrackedNativeTouchData> Touches { get; private set; }
#elif UNITY_IOS
        public NativeHashMapList<int2, TrackedNativeTouchData> Touches { get; private set; }
#endif

        //We will keep Ended touch alive for one set before removing them in the next set, so you can detect which one just goes up.
        //Two native list will switch back and forth like rendering's double buffering.
#if UNITY_ANDROID
        private NativeList<int> _keyOfEnded;
        private NativeList<int> _keyOfEnded2;
        private NativeList<int> KeyOfEnded => endedBuffer == EndedBuffer.Primary ? _keyOfEnded : _keyOfEnded2;
        private NativeList<int> KeyOfEndedClearing => endedBuffer == EndedBuffer.Primary ? _keyOfEnded2 : _keyOfEnded;
#elif UNITY_IOS
        private NativeList<int2> _keyOfEnded;
        private NativeList<int2> _keyOfEnded2;
        private NativeList<int2> KeyOfEnded => endedBuffer == EndedBuffer.Primary ? _keyOfEnded : _keyOfEnded2;
        private NativeList<int2> KeyOfEndedClearing => endedBuffer == EndedBuffer.Primary ? _keyOfEnded2 : _keyOfEnded;
#endif

        /// <summary>
        /// Make sure even if player use all of fingers and toes he still could not crash the game...
        /// </summary>
        public const int maximumTouch = 21;

        private NativeArray<int> _memory;
        private int touchIdRunner
        {
            get => _memory[0];
            set => _memory[0] = value;
        }

        private int screenHeight
        {
            get => _memory[1];
            set => _memory[1] = value;
        }

        // Ended touch might has key collision with a new one immediately after. We try to offset it.
        private int endedKeyTransformOffset
        {
            get => _memory[2];
            set => _memory[2] = value;
        }

        private EndedBuffer endedBuffer 
        {
            get => _memory[3] == 0 ? EndedBuffer.Primary : EndedBuffer.Secondary;
            set => _memory[3] = value == EndedBuffer.Primary ? 0 : 1;
        }

        enum EndedBuffer
        {
            Primary,
            Secondary
        }

        private void SwitchEndedBuffer() { endedBuffer = endedBuffer == EndedBuffer.Primary ? EndedBuffer.Secondary : EndedBuffer.Primary; }

        private const int endedKeyTransformBase = 100000;
        private const int endedKeyTransformMax = 100000;

        /// <param name="screenHeight">If you change your screen orientation this needs to be reinstantiated as well..</param>
        public NativeTouchTracker(int screenHeight, Allocator allocator)
        {
#if UNITY_ANDROID
            Touches = new NativeHashMapList<int, TrackedNativeTouchData>(maximumTouch, allocator);
            _keyOfEnded = new NativeList<int>(maximumTouch, allocator);
            _keyOfEnded2 = new NativeList<int>(maximumTouch, allocator);
#elif UNITY_IOS
            Touches = new NativeHashMapList<int2, TrackedNativeTouchData>(maximumTouch, allocator);
            _keyOfEnded = new NativeList<int2>(maximumTouch, allocator);
            _keyOfEnded2 = new NativeList<int2>(maximumTouch, allocator);
#endif
            _memory = new NativeArray<int>(4, allocator);

            this.endedBuffer = EndedBuffer.Primary;
            this.endedKeyTransformOffset = 0;
            this.touchIdRunner = 0;
            this.screenHeight = screenHeight;
        }

        /// <summary>
        /// If an orientation change makes the screen height different you need to update it.
        /// </summary>
        public void SetScreenHeight(int screenHeight)
        {
            this.screenHeight = screenHeight;
        }

        /// <summary>
        /// If your screen rotates or other problems just dispose and create a new one!
        /// </summary>
        public void Dispose()
        {
            Touches.Dispose();
            _memory.Dispose();
            _keyOfEnded.Dispose();
            _keyOfEnded2.Dispose();
        }

        /// <summary>
        /// Feed touch data here SEQUENTIALLY CORRECTLY.
        /// An error will throw on any confusion the tracker think it cannot figure out what to do.
        /// </summary>
        public void Track(ref NativeTouchData ntd)
        {
#if DEBUG_POINT_TRACKER
            DebugLog($"-- TRACKING {ntd}", LogType.Log);
#endif
            //Switch case on enum is fast on Burst compile.
            switch (ntd.Phase)
            {
                case TouchPhase.Began:
                    {
                        RegisterNewTouch(ref ntd);
                        break;
                    }
                case TouchPhase.Ended:
                case TouchPhase.Moved:
                case TouchPhase.Canceled:
                    {
                        ProgressTouch(ref ntd);
                        break;
                    }
                    // {
                    //     Panic();
                    //     break;
                    // }
                case TouchPhase.Stationary: break; //Only iOS can give us this when multitouching.
            }
        }

        /// <summary>
        /// Call this on `OnApplicationPause(false)` to prevent random Cancelled phase wrecking the tracker.
        /// </summary>
        public void Panic()
        {
            Touches.Clear();
            _keyOfEnded.Clear();
            _keyOfEnded2.Clear();
        }

        /// <summary>
        /// - When ending a set the tracked movement vector will reset its first position on the next `Track` call.
        /// - When ending a set any point that has not moved at all since the last set will get Stationary phase.
        /// - When ending a set the touch preserved due to Ended phase will be replaced with the lastest set's Ended touches.
        /// This means if you check the `Touches` list while not ending a set yet, you will see both new Ended of the current set
        /// and previous Ended preserved from the previous set.
        /// </summary>
        public void EndSet()
        {
            // Remove old Ended / Canceled. This is the only place the `Touches` list can decrease its count.
            for (int i = 0; i < KeyOfEndedClearing.Length; i++)
            {
#if DEBUG_POINT_TRACKER
                Debug.Log($"Removing ended touch with key {KeyOfEndedClearing[i]}");
#endif
                Touches.RemoveByKey(KeyOfEndedClearing[i]);
            }
            KeyOfEndedClearing.Clear();
            SwitchEndedBuffer();

            //Ending a set affects all touches.
            var hml = Touches;
            for (int i = 0; i < Touches.Length; i++)
            {
                var toEndSet = hml[i];
                toEndSet.EndSet();
                hml[i] = toEndSet;
            }
        }

        private void RegisterNewTouch(ref NativeTouchData ntd)
        {
            var toAdd = new TrackedNativeTouchData(ref ntd, touchIdRunner, screenHeight);
            touchIdRunner++;
#if UNITY_ANDROID
            if (!Touches.TryAdd(ntd.PointerId, toAdd))
            {
                throw new NativeTouchTrackerException($"Registering new touch {ntd} failed!");
            }
#if DEBUG_POINT_TRACKER
            else
            {
                DebugLog($"Registering new touch {ntd} ID {ntd.PointerId} tracked as {toAdd}.", LogType.Log);
            }
#endif
#elif UNITY_IOS
            if (!Touches.TryAdd(new int2(ntd.IntegerX, screenHeight - ntd.IntegerY), toAdd))
            {
                throw new NativeTouchTrackerException($"Registering new touch {ntd} failed!");
            }
#if DEBUG_POINT_TRACKER
            else
            {
                DebugLog($"Registering new touch {ntd} tracked as {toAdd}.", LogType.Log);
            }
#endif
#else
        throw new NativeTouchTrackerException($"You can only use {nameof(NativeTouchTracker)} with iOS and Android...");
#endif
        }

        private void ProgressTouch(ref NativeTouchData ntd)
        {
#if UNITY_ANDROID
            var key = ntd.PointerId;
            if (!Touches.TryGetValue(key, out var toProgress))
            {
                throw new NativeTouchTrackerException($"No such key {key} while trying to progress a touch {ntd} !");
            }
#elif UNITY_IOS
            var key = new int2(ntd.PreviousIntegerX, screenHeight - ntd.PreviousIntegerY);
            //Debug.Log($"Using key {key} to progress");
            if (!Touches.TryGetValue(key, out var toProgress))
            {
                //Check if it is a duplicated event?
                var secondaryKey = new int2(ntd.IntegerX, screenHeight - ntd.IntegerY);
                if (Touches.TryGetValue(secondaryKey, out var toProgress2))
                {
                    //It is a duplicated event, we ignore this.
                    //However if the state is Ended or Cancelled, there is something to progress
                    //just in case the previous (duplicated) progression was Moved. (preparing to remove the touch from a list)
                    if (!(ntd.Phase == TouchPhase.Ended || ntd.Phase == TouchPhase.Canceled))
                    {
                        return;
                    }
                    toProgress = toProgress2;
                    key = secondaryKey;
                }
                else
                {
                    if(ntd.Phase == TouchPhase.Canceled)
                    {
                        throw new NativeTouchTrackerException($"This {ntd} touch key {key} is a stray Cancelled!! Are you calling `Panic()` correctly when the game coming back from the background?");
                    }
                    else
                    {
                        throw new NativeTouchTrackerException($"No such key {key} while trying to progress a touch {ntd} !");
                    }
                }
            }
#endif

#if DEBUG_POINT_TRACKER
            DebugLog($"Progressing : {toProgress} with {ntd}", LogType.Log);
#endif

            bool progressToEnded = toProgress.Progress(ref ntd, screenHeight);

#if DEBUG_POINT_TRACKER
            DebugLog($"Progression result : {toProgress}", LogType.Log);
#endif
#if UNITY_IOS
            //On iOS we don't have an ID but match with a coordinate, 
            //it is necessary to update the key after a progression as well.
            var newKey = toProgress.position;
            if (!Touches.TryChangeKey(key, newKey))
            {
                throw new NativeTouchTrackerException($"Changing key {key} to {newKey} failed!");
            }
            if (!Touches.TrySetValue(newKey, toProgress))
            {
                throw new NativeTouchTrackerException($"Setting {toProgress} to {newKey} failed!");
            }

            if (progressToEnded)
            {
                var transformedKey = EndedKeyTransform(newKey);
                if (!Touches.TryChangeKey(newKey, transformedKey))
                {
                    throw new NativeTouchTrackerException($"Transforming key for ended : key {newKey} to {transformedKey} failed!");
                }
#if DEBUG_POINT_TRACKER
                    Debug.Log($"Ended key added {transformedKey}");
#endif
                KeyOfEnded.Add(transformedKey);
            }
#else
            if(!Touches.TrySetValue(key, toProgress))
            {
                throw new NativeTouchTrackerException($"Setting {toProgress} to {key} failed!");
            }

            if(progressToEnded)
            {
                //When this happen, we have to migrate the key of ending touch to something else
                //We are preserving the Ended touch in the same HashMap, if a new touch with exactly the same key comes in quickly in up-down sequence
                //(iOS - up down in same coordinate, Android - up down in same ID) it will explode...
                //This touch's key will not be referenced again anyways?
                var transformedKey = EndedKeyTransform(key);
                if(!Touches.TryChangeKey(key, transformedKey))
                {
                    throw new NativeTouchTrackerException($"Transforming key for ended : key {key} to {transformedKey} failed!");
                }

                //For Android the touch comes in pack, and a pack contains only 1 state. It is impossible to get duplicated Ended?
#if DEBUG_POINT_TRACKER
                Debug.Log($"Ended key added {transformedKey}");
#endif
                KeyOfEnded.Add(transformedKey);
            }
#endif
        }

#if UNITY_IOS
        private int2 EndedKeyTransform(int2 oldKey)
#elif UNITY_ANDROID
        private int EndedKeyTransform(int oldKey)
#endif
        {
            endedKeyTransformOffset = (endedKeyTransformOffset + 1) % endedKeyTransformMax;
            //+1 to prevent 0 identity
            return (oldKey + 1) * (endedKeyTransformBase + endedKeyTransformOffset);
        }

        private void DebugLog(string message, LogType logType)
        {
#if DEBUG_POINT_TRACKER
            switch (logType)
            {
                case LogType.Log: { Debug.Log(message); return; }
                case LogType.Warning: { Debug.LogWarning(message); return; }
                case LogType.Error: { Debug.LogError(message); return; }
                default: { Debug.Log(message); return; }
            }
#endif
        }
    }

    [System.Serializable]
    public class NativeTouchTrackerException : System.Exception
    {
        public NativeTouchTrackerException() { }
        public NativeTouchTrackerException(string message) : base(message) { }
        public NativeTouchTrackerException(string message, System.Exception inner) : base(message, inner) { }
        protected NativeTouchTrackerException(
            System.Runtime.Serialization.SerializationInfo info,
            System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }


}