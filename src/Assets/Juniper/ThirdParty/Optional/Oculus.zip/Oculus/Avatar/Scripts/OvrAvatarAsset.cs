﻿#if OCULUS
﻿using System;

public class OvrAvatarAsset {
    public UInt64 assetID;
}

#endif