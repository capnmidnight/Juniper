﻿#if OCULUS
namespace Oculus.Platform
{
  using System;

  [Serializable]
  public sealed class OculusStandalonePlatformResponse
  {
    public string access_token;
  }
}

#endif