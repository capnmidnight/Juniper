﻿#if OCULUS
// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

namespace Oculus.Platform
{

  using Description = System.ComponentModel.DescriptionAttribute;

  public enum ServiceProvider : int
  {
    [Description("UNKNOWN")]
    Unknown,

    [Description("DROPBOX")]
    Dropbox,

    [Description("FACEBOOK")]
    Facebook,

    [Description("GOOGLE")]
    Google,

    [Description("INSTAGRAM")]
    Instagram,

    [Description("REMOTE_MEDIA")]
    RemoteMedia,

  }

}

#endif