﻿#if OCULUS
// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

namespace Oculus.Platform
{

  using Description = System.ComponentModel.DescriptionAttribute;

  public enum MatchmakingStatApproach : int
  {
    [Description("UNKNOWN")]
    Unknown,

    [Description("TRAILING")]
    Trailing,

    [Description("SWINGY")]
    Swingy,

  }

}

#endif