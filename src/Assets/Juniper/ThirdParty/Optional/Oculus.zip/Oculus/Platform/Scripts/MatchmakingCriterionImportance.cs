﻿#if OCULUS
// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

namespace Oculus.Platform
{

  using Description = System.ComponentModel.DescriptionAttribute;

  public enum MatchmakingCriterionImportance : int
  {
    [Description("REQUIRED")]
    Required,

    [Description("HIGH")]
    High,

    [Description("MEDIUM")]
    Medium,

    [Description("LOW")]
    Low,

    [Description("UNKNOWN")]
    Unknown,

  }

}

#endif