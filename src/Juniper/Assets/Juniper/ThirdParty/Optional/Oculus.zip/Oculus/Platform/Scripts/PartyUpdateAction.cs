// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

namespace Oculus.Platform
{

  using Description = System.ComponentModel.DescriptionAttribute;

  public enum PartyUpdateAction : int
  {
    [Description("UNKNOWN")]
    Unknown,

    [Description("Join")]
    Join,

    [Description("Leave")]
    Leave,

    [Description("Invite")]
    Invite,

    [Description("Uninvite")]
    Uninvite,

  }

}
