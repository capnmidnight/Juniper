namespace Oculus.Platform.Samples.VrHoops
{
	using UnityEngine;
	using System.Collections;

	public class BallEjector : MonoBehaviour {

	}
}
