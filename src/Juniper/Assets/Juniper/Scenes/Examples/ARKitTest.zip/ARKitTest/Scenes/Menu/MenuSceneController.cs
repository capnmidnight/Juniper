using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuSceneController : MonoBehaviour
{
    private void Start()
    {
        var backButton = transform.GetChild(0).gameObject;
        backButton.SetActive(NoNativeBackButton);

        var bounds = (RectTransform)transform.GetChild(1);
        var prefab = bounds.gameObject;

        if (InMainMenu)
        {
            for (var i = 1; i < SceneManager.sceneCountInBuildSettings; ++i)
            {
                var child = Instantiate(prefab);
                var trans = (RectTransform)child.transform;
                var text = child.GetComponentInChildren<Text>();
                var button = child.GetComponent<Button>();
                var n = i;
                text.text = $"Scene {i}";
                trans.SetParent(bounds.parent);
                trans.anchoredPosition = Vector3.down * (i - 1) * 90;
                trans.anchorMin = Vector2.up;
                trans.anchorMax = Vector2.one;
                trans.sizeDelta = 80 * Vector2.up;
                button.onClick.AddListener(() =>
                    LoadScene(n));
            }
        }

        Destroy(prefab);
    }

    private bool NoNativeBackButton =>
        Application.platform == RuntimePlatform.IPhonePlayer
                || Application.platform == RuntimePlatform.WindowsEditor
                || Application.platform == RuntimePlatform.LinuxEditor
                || Application.platform == RuntimePlatform.OSXEditor;

    private bool InMainMenu
    {
        get
        {
            var scene = SceneManager.GetActiveScene();
            return scene.buildIndex == 0;
        }
    }

    public void LoadScene(int index)
    {
        print($"Loading scene {index}");
        var currentIndex = SceneManager.GetActiveScene().buildIndex;
        if (index != currentIndex)
        {
            SceneManager.LoadScene(index, LoadSceneMode.Single);
        }
    }

    public void Back()
    {
        if (InMainMenu)
        {
            Quit();
        }
        else
        {
            LoadScene(0);
        }
    }

    public static void Quit() =>
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;

#else
        Application.Quit();
#endif

    public void Update()
    {
        if (UnityEngine.Input.GetKey(KeyCode.Escape))
        {
            Back();
        }
    }
}
