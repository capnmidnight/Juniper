﻿Low Poly Paper Boats Package

Contents:
	Mesh:
	Birda
	Black Pearl
	Speedy
	Super Sail
	Tiny
	White Fang
	
	Texture:
	boat_texture.png
	
	Material:
	boat_material

Assets Function:
	All Boats are simple Props that can be used as side assets or main assets for unity games and apps.
	
Method of Installation:
	Just import the package and the boats will be available to use in your scene.
