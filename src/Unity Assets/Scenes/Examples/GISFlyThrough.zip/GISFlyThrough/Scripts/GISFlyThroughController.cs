using UnityEngine;

namespace Juniper.Examples.GISFlyThroughDemo
{
    public class GISFlyThroughController : MonoBehaviour
    {
    }
}
