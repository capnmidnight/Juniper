Hitachi Vantara - Optimized Factory
===================================

This is an AR app for trouble-shooting industrial equipment in an Enterprise
Resource Planned environment deployed with IoT devices.

Configuring the HoloLens
========================

See Development notes on how to install the application.

NOTE: if you experience issues with the compressor graphic appearing as if it is
"swimming", the application needs to be configured for the user's Inter-Pupilary
Distance (IPD). IPD is a biometric property that specifies the distance between
the two pupils of a persons eyes. *It is different for everyone*. Too small of
an IPD value will cause the graphics to appear closer than they are physically
located. Too large and the graphics will appear farther away.

The Windows Setup menu has a Utility for calibrating the HoloLens per-user.

-   `Bloom` to open the Start Menu

-   `Air Tap` to select "Settings"

-   `Air Tap` to select "System"

-   In the left-side of the window, `Air Tap` to select "Utilities"

-   `Air Tap` to select "Open Calibration"

-   Follow the on-screen prompts.

The calibration process takes approximately two minutes, which is somewhat
lengthy for demo purposes.

The IPD can also be set manually in the Windows Device Portal. See details below
on gaining access to the Device Portal. This is the fastest way to change the
IPD setting, and can even be done over Wi-Fi, but it does require the user to
know their personal IPD, or have it measured, prior to using the app.

Commands That Are Always Available
----------------------------------

All scene views have the following spoken commands available:

-   "Simulate" - Toggle Sensor Data Simulation Mode, which cuts accessing live
    data and simulates sensor data. The default value is to simulate data.

-   "Demo" - Toggle Demo Visualization Mode, which renders a 3D model of the
    compressor, in case there is no compressor available.

-   "Quit" - Exit the application.

-   "Nose" - Activate nose-pointer mode. The default is to have it enabled.

-   "Hand" - Activate hand-pointer mode.

-   "Geiger" - Activate the frame-drop notifier.

-   "Show" - Show a visualization of the spatial mesh.

-   "Hide" - Hide the spatial mesh visualization.

Main Menu View
--------------

The app starts in the Menu, where the "Start" button is visible to enter the
Asset View mode. You may long-gaze at the button, gaze-and-air-tap, or point a
cursor from your hand to click on the button directly.

Additionally, there are two keyword commands available:

-   "Start" - The same as clicking the "Start" button.

-   "Setup" - Enter a hidden mode for positioning the 3D model of the compressor
    on top of the real compressor unit.

Setup View
----------

The Setup View is used to position the 3D model of the compressor on top of the
real compressor unit, so that the alerts and animations register and composite
with the asset.

The available keywords commands are:

-   "Translate" - grabbing and dragging the control handle spheres on the X, Y,
    and Z axis of the model moves the model laterally.

-   "Rotate" - grabbing and dragging the control handle spheres rotates the
    model in that axis.

-   "Scale" - grabbing and dragging the control handle spheres resizes the model
    along that axis.

-   "Fast" (default) - the transforms move 1-to-1 with the control handle
    movement.

-   "Slow" - the transforms move at 1/5th the speed of the control handle
    movement.

-   "Done" - return to the Main Menu.

Asset View
----------

The Asset View demonstrates the use of the HoloLens in a troubleshooting
scenario. There is HUD that directs the user's attention to points of interest
along the way. Follow the attention director and click on the active buttons and
elements to progress through the demo. The demo ends when all of the
troubleshooting steps have been completed.

The available keyword commands are:

-   "Alerts" - start the troubleshooting mode.

-   "Next" - advance to the next troubleshooting screen.

-   "Menu" - return to the asset summary view.

-   "Restart", "Reset", "Exit" - returns the user to the Main Menu.

-   "Explode" - toggle an explosion view of the model.

AirCast
-------

See Microsoft's documentation on [connecting the HoloLens to WiFi and
discovering the IP address of the
HoloLens](https://docs.microsoft.com/en-us/windows/mixed-reality/connecting-to-wi-fi-on-hololens)
to connect to the Device Portal over WiFi.

Development Requirements
========================

Tools
-----

[Microsoft's installation checklist for
HoloLens](https://developer.microsoft.com/en-us/windows/mixed-reality/install_the_tools)

With this project, for development we are using:

-   [Visual Studio 2017](http://dev.windows.com/downloads) on Windows 10
    Enterprise

    -   Visual Studio 2017 only runs on Windows.

    -   Visual Studio Code is not sufficient, it's actually a completely
        different product.

    -   Community Edition is fine, but I prefer Professional for the project
        analysis tools.

    -   It's similar to the situation with iOS applications requiring XCode for
        the final build step, with XCode only running on macOS. You can use
        Unity from macOS or Linux, and generate the UWP project from those
        operating systems, but you need a Windows computer running at least
        Visual Studio 2017 Community to build the UWP project and deploy it to
        the HoloLens.

    -   You will also need the following plugins (use the Visual Studio
        streaming installer to install them):

        -   Workloads: Universal Windows Platform development (Workload)

        -   Mobile & Gaming: Game Development with Unity

        -   Individual Component: Windows 10 SDK (10.0.16299.0) for UWP: C\#,
            VB, JS

    -   If you already have Visual Studio 2017 installed, but aren't sure if you
        have the required tools, open Visual Studio and click `Tools > Get Tools
        and Features...`. A dialog will open in which you can find and install
        the required features.

-   [Unity Editor v2017.2.0f3](https://unity3d.com/get-unity/download/archive)

    -   This is the latest version of Unity in which the
        `HolographicSettings.SetFocusPointForFrame` feature is not defective.

    -   This is an essential feature for Hologram stability. We won't be able to
        upgrade to a later version of Unity until this defect is fixed.

    -   For more information, see [Unity Forums: SetFocusPointForFrame Seems to
        Make Things
        Worse](https://forum.unity.com/threads/holographicsettings-setfocuspointforframe-seems-to-make-things-worse-hololens.514103/).

Unity Project Configuration
===========================

Player Settings
---------------

### Other

Pay special attention to the `Scripting Define Symbols` field. It must contain
"HOLOLENS".

![Player: Other Settings](media/519e4b7559bec758dc3ea492a7166436.png)

Player: Other Settings

### Publish

The Universal Windows Platform has a capabilities-based permissions system,
similar to the latest versions of Android. You should make sure at least the
following Capabilities are checked:

-   `InternetClient` - necessary to connect to the Hitachi asset API.

-   `PicturesLibrary` and `VideosLibrary` - necessary to be able to take
    screenshots and video-captures through the HoloLens view.

-   `WebCam` - necessary both for screenshots/video-captures and Vuforia
    integration.

-   `Microphone` - necessary for speech recognition.

-   `SpatialPerception` - necessary for the key feature of the HoloLens.

### XR

![Player: XR Settings](media/437bb72554e0851bf264c420d39a8983.png)

Player: XR Settings

Build Settings
--------------

![Build Settings](media/5bdc7b9c54d819ae55378ff4fe655b3f.png)

Build Settings

If the "Unity C\# Projects" option is not available, it's usually because the
`Player Settings > XR Settings` haven't been configured correctly.

Testing Requirements
====================

Either: - For real, with a HoloLens, or - In the emulator: - [Windows 10 Fall
Creators Update](https://www.microsoft.com/en-us/software-download/windows10) -
[HoloLens Simulator](https://go.microsoft.com/fwlink/?linkid=852626)

Configuring the HoloLens
========================

The HoloLens needs the sensors to be calibrated for the local environment, and
be configured for Developer access.

Run the Calibration and Sensor Tuning Processes
-----------------------------------------------

-   Turn on the HoloLens and put it on your noggin.

-   Perform the `Bloom` gesture to open the Start Menu.

-   `Air Tap` the Gear Icon "Settings" item in the Start Menu.

-   `Air Tap` the "System" item near the beginning of the list.

-   `Air Tap` the "Utilities" list item on the left side of the window.

-   `Air Tap` the "Open Calibration" button in the window.

    -   Follow the on-screen prompts until calibration is complete.

    -   Return to the "Utilities" screen.

-   `Air Tap` the "Open Sensor Tuning" button in the window.

    -   Follow the on-screen prompts until sensor tuning setup.

    -   Set the HoloLens aside for approximately 5 minutes for the tuning
        process to complete.

Enable Windows Developer Portal on HoloLens
-------------------------------------------

-   Turn on the HoloLens and put it on your head.

-   Perform the `Bloom` gesture to open the Start Menu.

-   `Air Tap` the Gear Icon Settings" item in the Start Menu.

-   `Air Tap` the "Update & Security" item near the end of the list.

-   `Air Tap` the "For developers" list item on the left side of the window.

-   `Air Tap` to toggle the "Developer mode" slider box to the "On" position.

-   `Air Tap and Hold` to scroll down to the end of the page.

-   `Air Tap` to toggle the "Device Portal" slider box to the "On" position.

-   Configure the access credentials for the Developer Portal to something that
    will be easy to type with your nose.

Configure the Developer Portal
------------------------------

-   Open your favorite flavor of web browser.

-   Connect the HoloLens to your PC via the provided USB cable.

-   Enter the HoloLens' Developer Portal address (127.0.0.1:10080).

-   Enter the access credentials for the Developer Portal.

-   Select the "Mixed Reality Capture" item in the menu on the left side of the
    page.

-   Under the "Capture" heading:

    -   Check "Holograms"

    -   Check "PV Camera"

    -   Check "Mic Audio"

    -   Check "App Audio"

    -   Select "High (720p, 30fps, 5Mbits)" from the "Live preview quality"
        drop-down.

Build Process
=============

Basic Development
-----------------

If you are creating/editing/deleting any object in the Unity editor, or
creating/deleting C\# scripts, or doing anything that doesn't require direct
access to HoloLens-specific features, use Unity as usual. The Juniper
Framework will create a regular, monoscopic camera setup and provide WASD-type
mouse-and-keyboard input to let you test your work directly in the editor.

On-HoloLens Development and Deployment
--------------------------------------

If you are only editing existing C\# scripts, need to iterate on code that
relies on HoloLens-specific features, run the application on-device with the
debugger attached, or need to deploy the application, you will need to do a full
Build:

### Generating a Visual Studio UWP Solution.

Every time you create/edit/delete an object in the scene in Unity (including
adding Components to objects), and every time you create/delete C\# scripts for
the project, you need to regenerate the Visual Studio UWP project:

-   Open `File > Build Settings... CTRL+SHIFT+B`.

-   Click `Build`.

-   Select the `UWP` directory in the project root.

-   Go get coffee and a snack...

-   Unity will open Windows Explorer to the project root directory:

    -   Open the `UWP` directory.

    -   Open the `.sln` file contained therein. This is a separate solution file
        from the one in the project root. It is not a Unity/Mono project, it is
        a full Windows UWP project. Please try to keep the two straight, as
        there are APIs each support that the other does not and there are C\#
        language features available in UWP that are not available in the Unity
        Editor.

    -   Immediately change the Build Platform drop-down next to the Run button
        from `ARM` to `x86`. Unity does not generate the project correctly and
        your project will not build if the platform is set to ARM.

#### Debug Builds

Debug builds are good for stepping through issues directly on the HoloLens, but
their performance is particularly bad. The time it takes to build the app,
deploy it to the HoloLens, and connect the debugger is longer than it takes to
build and deploy a Release build, so you should stick to Debug builds only when
you absolutely need to attach the debugger.

-   Connect the HoloLens to your development PC by a micro USB cable.

-   Set the Build Configuration drop-down to `Debug`.

-   Set the Target Device:

    -   If it says `Attach to Unity` you're in the wrong project.

    -   If it says `Local Machine`, change it to `Device`.

-   Click the green `Play` triangle button.

-   If this is the first time you are testing on the HoloLens, you'll be asked
    to enter a Paring PIN. SEE *Pairing a HoloLens to a Development PC*.

-   The application should start automatically. If you don't see anything after
    a while, keep an eye on the debug view of Visual Studio to make sure the
    application did not crash during startup.

#### Deploying Release Builds

Release builds are good for testing the app in a partially optimized state. The
build time is not very long and the application performance is good enough for
most use cases.

-   The steps are mostly the same as the `Debug` build.

-   Set the Build Configuration drop-down to `Release` instead of `Debug`.

-   Instead of clicking the green `Play` triangle, select `Build > Deploy
    Solution` from the menu bar.

-   On the HoloLens:

    -   `Bloom` your hand to open the Start Menu,

    -   `AirTap` the "More" plus on the right side of the menu,

    -   Find and `AirTap` the `Optimized Facto...` project in the menu,

    -   `AirTap` to place the object in your immediate vicinity.

#### Deploying Master Builds

A Master build should be used for versions of the application intended for
users. The Master build performs additional optimizations over release build and
provides the best performance of all the build types.

-   The steps are nearly identical to those of the `Release` build.

-   Set the Build Configuration drop-down to `Master` instead of `Release`.

-   The build takes significantly longer, so go get a snack.

#### Pairing a HoloLens to a Development PC

The first time you deploy an app from Visual Studio to your HoloLens, you will
be prompted for a PIN. On the HoloLens, generate a PIN by launching the Settings
app, go to `Update > For Developers` and tap on `Pair`. A PIN will be displayed
on your HoloLens; type this PIN in Visual Studio. After pairing is complete, tap
Done on your HoloLens to dismiss the dialog. This PC is now paired with the
HoloLens and you will be able to deploy apps automatically. Repeat these steps
for every subsequent PC that is used to deploy apps to your HoloLens.

To un-pair your HoloLens from all computers it was paired with, launch the
Settings app, go to Update \> For Developers and tap on Clear.

APPENDIX A: Background Information and Design Guidelines
--------------------------------------------------------

Please read:

-   (optional) Read through the
    [Fundamentals](https://docs.microsoft.com/en-us/windows/mixed-reality/mixed-reality)
    pages for more information on MR, Holograms, and the HoloLens hardware.

-   [Windows Mixed Reality
    Academy](https://docs.microsoft.com/en-us/windows/mixed-reality/academy),
    and

-   [WMR Design
    Guidance](https://docs.microsoft.com/en-us/windows/mixed-reality/design)

-   All of the [HoloLens
    how-to](https://docs.microsoft.com/en-us/windows/mixed-reality/accounts-on-hololens)
    pages.
