﻿using UnityEngine;

public enum ColorValues
{
    R,
    G,
    B,
    A,

    Hue,
    Saturation,
    Value
}
