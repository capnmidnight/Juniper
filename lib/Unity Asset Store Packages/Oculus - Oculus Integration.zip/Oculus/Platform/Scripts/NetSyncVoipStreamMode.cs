// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

namespace Oculus.Platform
{

  using Description = System.ComponentModel.DescriptionAttribute;

  public enum NetSyncVoipStreamMode : int
  {
    [Description("UNKNOWN")]
    Unknown,

    [Description("AMBISONIC")]
    Ambisonic,

    [Description("MONO")]
    Mono,

  }

}
