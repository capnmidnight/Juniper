// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

namespace Oculus.Platform
{

  using Description = System.ComponentModel.DescriptionAttribute;

  public enum NetSyncConnectionStatus : int
  {
    [Description("UNKNOWN")]
    Unknown,

    [Description("CONNECTING")]
    Connecting,

    [Description("DISCONNECTED")]
    Disconnected,

    [Description("CONNECTED")]
    Connected,

  }

}
