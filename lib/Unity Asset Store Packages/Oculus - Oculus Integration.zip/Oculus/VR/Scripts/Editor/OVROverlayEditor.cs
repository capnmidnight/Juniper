using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(OVROverlay))]
public class OVROverlayEditor : Editor
{

	/// <summary>
	/// Common Video Types, to ease source and dest rect creation
	/// </summary>
	public enum StereoType
	{
		Custom = 0,
		Mono = 1,
		Stereo = 2,
		StereoLeftRight = 3,
		StereoTopBottom = 4,
	}

	public enum DisplayType
	{
		Custom = 0,
		Full = 1,
		Half = 2
	}

	private bool sourceRectsVisible = false;
	private bool destRectsVisible = false;

	private Material _SrcRectMaterial;
	protected Material SrcRectMaterial
	{
		get
		{
			if (_SrcRectMaterial == null)
			{
				string[] shaders = AssetDatabase.FindAssets("OVROverlaySrcRectEditor");

				if (shaders.Length > 0)
				{
					Shader shader = (Shader)AssetDatabase.LoadAssetAtPath(AssetDatabase.GUIDToAssetPath(shaders[0]), typeof(Shader));

					if (shader != null)
					{
						_SrcRectMaterial = new Material(shader);
					}
				}
			}
			return _SrcRectMaterial;
		}
	}

	private Material _DestRectMaterial;
	protected Material DestRectMaterial
	{
		get
		{
			if (_DestRectMaterial == null)
			{
				string[] shaders = AssetDatabase.FindAssets("OVROverlayDestRectEditor");

				if (shaders.Length > 0)
				{
					Shader shader = (Shader)AssetDatabase.LoadAssetAtPath(AssetDatabase.GUIDToAssetPath(shaders[0]), typeof(Shader));

					if (shader != null)
					{
						_DestRectMaterial = new Material(shader);
					}
				}
			}
			return _DestRectMaterial;
		}
	}

	private TextureRect _DraggingRect;
	private Side _DraggingSide;

	enum TextureRect
	{
		None,
		SrcLeft,
		SrcRight,
		DestLeft,
		DestRight
	}

	enum Side
	{
		Left,
		Right,
		Top,
		Bottom
	}

	public override void OnInspectorGUI()
	{
		OVROverlay overlay = (OVROverlay)target;
		if (overlay == null)
		{
			return;
		}

		EditorGUILayout.LabelField("Display Order", EditorStyles.boldLabel);
		overlay.currentOverlayType = (OVROverlay.OverlayType)EditorGUILayout.EnumPopup(new GUIContent("Current Overlay Type", "Whether this overlay should layer behind the scene or in front of it"), overlay.currentOverlayType);
		overlay.compositionDepth = EditorGUILayout.IntField(new GUIContent("Composition Depth", "Depth value used to sort OVROverlays in the scene, smaller value appears in front"), overlay.compositionDepth);
		overlay.noDepthBufferTesting = EditorGUILayout.Toggle(new GUIContent("No Depth Buffer Testing", "The noDepthBufferTesting will stop layer's depth buffer compositing even if the engine has \"Shared Depth Buffer\" enabled"), overlay.noDepthBufferTesting);
		EditorGUILayout.Space();

		EditorGUILayout.LabelField(new GUIContent("Overlay Shape", "The shape of this overlay"), EditorStyles.boldLabel);
		overlay.currentOverlayShape = (OVROverlay.OverlayShape)EditorGUILayout.EnumPopup(new GUIContent("Overlay Shape", "The shape of this overlay"), overlay.currentOverlayShape);
		EditorGUILayout.Space();

		EditorGUILayout.Separator();
		EditorGUILayout.LabelField("Textures", EditorStyles.boldLabel);

#if UNITY_ANDROID
		bool lastIsExternalSurface = overlay.isExternalSurface;
		overlay.isExternalSurface = EditorGUILayout.Toggle(new GUIContent("Is External Surface", "On Android, retrieve an Android Surface object to render to (e.g., video playback)"), overlay.isExternalSurface);

		if (lastIsExternalSurface)
		{
			overlay.externalSurfaceWidth = EditorGUILayout.IntField("External Surface Width", overlay.externalSurfaceWidth);
			overlay.externalSurfaceHeight = EditorGUILayout.IntField("External Surface Height", overlay.externalSurfaceHeight);
			overlay.isProtectedContent = EditorGUILayout.Toggle(new GUIContent("Is Protected Content", "The external surface has L1 widevine protection."), overlay.isProtectedContent);
		}
		else
#endif
		{
			if (overlay.textures == null)
			{
				overlay.textures = new Texture[2];
			}
			if (overlay.textures.Length < 2)
			{
				Texture[] tmp = new Texture[2];
				for (int i = 0; i < overlay.textures.Length; i++)
				{
					tmp[i] = overlay.textures[i];
				}
				overlay.textures = tmp;
			}

			var labelControlRect = EditorGUILayout.GetControlRect();
			EditorGUI.LabelField(new Rect(labelControlRect.x, labelControlRect.y, labelControlRect.width / 2, labelControlRect.height), new GUIContent("Left Texture", "Texture used for the left eye"));
			EditorGUI.LabelField(new Rect(labelControlRect.x + labelControlRect.width / 2, labelControlRect.y, labelControlRect.width / 2, labelControlRect.height), new GUIContent("Right Texture", "Texture used for the right eye"));


			var textureControlRect = EditorGUILayout.GetControlRect(GUILayout.Height(64));

			overlay.textures[0] = (Texture)EditorGUI.ObjectField(new Rect(textureControlRect.x, textureControlRect.y, 64, textureControlRect.height), overlay.textures[0], typeof(Texture), true);
			Texture right = (Texture)EditorGUI.ObjectField(new Rect(textureControlRect.x + textureControlRect.width / 2, textureControlRect.y, 64, textureControlRect.height), overlay.textures[1] != null ? overlay.textures[1] : overlay.textures[0], typeof(Texture), true);
			if (right == overlay.textures[0])
			{
				overlay.textures[1] = null;
			}
			else
			{
				overlay.textures[1] = right;
			}

			overlay.isDynamic = EditorGUILayout.Toggle(new GUIContent("Dynamic Texture", "This texture will be updated dynamically at runtime (e.g., Video)"), overlay.isDynamic);
#if !UNITY_ANDROID
            overlay.isProtectedContent = EditorGUILayout.Toggle(new GUIContent("Is Protected Content", "The texture has copy protection, e.g., HDCP"), overlay.isProtectedContent);
#endif
		}
		if (overlay.currentOverlayShape == OVROverlay.OverlayShape.Cylinder || overlay.currentOverlayShape == OVROverlay.OverlayShape.Equirect || overlay.currentOverlayShape == OVROverlay.OverlayShape.Quad) {

			EditorGUILayout.Separator();
			EditorGUILayout.Space();
			EditorGUILayout.LabelField("Texture Rects", EditorStyles.boldLabel);

			bool lastOverrideTextureRectMatrix = overlay.overrideTextureRectMatrix;
			overlay.overrideTextureRectMatrix = !EditorGUILayout.Toggle(new GUIContent("Use Default Rects", overlay.textures[1] == null ? "If you need to use a single texture as a stereo image, uncheck this box" : "Uncheck this box if you need to clip you textures or layer"), !overlay.overrideTextureRectMatrix);

			if (lastOverrideTextureRectMatrix)
			{
				sourceRectsVisible = EditorGUILayout.Foldout(sourceRectsVisible, new GUIContent("Source Rects", "What portion of the source texture will ultimately be shown in each eye."));

				if (sourceRectsVisible)
				{
					var mat = SrcRectMaterial;

					if (mat != null)
					{
						Rect drawRect = EditorGUILayout.GetControlRect(GUILayout.Height(128 + 8));
						mat.SetVector("_SrcRectLeft", new Vector4(Mathf.Max(0.0f, overlay.srcRectLeft.x), Mathf.Max(0.0f, overlay.srcRectLeft.y), Mathf.Min(1.0f - overlay.srcRectLeft.x, overlay.srcRectLeft.width), Mathf.Min(1.0f - overlay.srcRectLeft.y, overlay.srcRectLeft.height)));
						mat.SetVector("_SrcRectRight", new Vector4(Mathf.Max(0.0f, overlay.srcRectRight.x), Mathf.Max(0.0f, overlay.srcRectRight.y), Mathf.Min(1.0f - overlay.srcRectRight.x, overlay.srcRectRight.width), Mathf.Min(1.0f - overlay.srcRectRight.y, overlay.srcRectRight.height)));
						// center our draw rect
						var drawRectCentered = new Rect(drawRect.x + drawRect.width / 2 - 128 - 4, drawRect.y, 256 + 8, drawRect.height);
						EditorGUI.DrawPreviewTexture(drawRectCentered, overlay.textures[0] ?? Texture2D.blackTexture, mat);

						var drawRectInset = new Rect(drawRectCentered.x + 4, drawRectCentered.y + 4, drawRectCentered.width - 8, drawRectCentered.height - 8);
						UpdateRectDragging(drawRectInset, drawRectInset, TextureRect.SrcLeft, TextureRect.SrcRight, ref overlay.srcRectLeft, ref overlay.srcRectRight);
						CreateCursorRects(drawRectInset, overlay.srcRectLeft);
						CreateCursorRects(drawRectInset, overlay.srcRectRight);
					}

					var labelControlRect = EditorGUILayout.GetControlRect();
					EditorGUI.LabelField(new Rect(labelControlRect.x, labelControlRect.y, labelControlRect.width / 2, labelControlRect.height), new GUIContent("Left Source Rect", "The rect in the source image that will be displayed on the left eye layer"));
					EditorGUI.LabelField(new Rect(labelControlRect.x + labelControlRect.width / 2, labelControlRect.y, labelControlRect.width / 2, labelControlRect.height), new GUIContent("Right Source Rect", "The rect in the source image that will be displayed on the right eye layer"));

					var rectControlRect = EditorGUILayout.GetControlRect(GUILayout.Height(34));

					overlay.srcRectLeft = Clamp01(EditorGUI.RectField(new Rect(rectControlRect.x, rectControlRect.y, rectControlRect.width / 2 - 20, rectControlRect.height), overlay.srcRectLeft));
					overlay.srcRectRight = Clamp01(EditorGUI.RectField(new Rect(rectControlRect.x + rectControlRect.width / 2, rectControlRect.y, rectControlRect.width / 2 - 20, rectControlRect.height), overlay.srcRectRight));


					EditorGUILayout.BeginHorizontal();
					if (overlay.textures[1] != null)
					{
						if (GUILayout.Button(new GUIContent("Reset To Default", "Reset Source Rects to default")))
						{
							SetRectsByVideoType(overlay, StereoType.Stereo, DisplayType.Custom);
						}
					}
					else
					{
						if (GUILayout.Button(new GUIContent("Monoscopic", "Display the full Texture in both eyes")))
						{
							SetRectsByVideoType(overlay, StereoType.Mono, DisplayType.Custom);
						}
						if (GUILayout.Button(new GUIContent("Stereo Left/Right", "The left half of the texture is displayed in the left eye, and the right half in the right eye")))
						{
							SetRectsByVideoType(overlay, StereoType.StereoLeftRight, DisplayType.Custom);
						}
						if (GUILayout.Button(new GUIContent("Stereo Top/Bottom", "The top half of the texture is displayed in the left eye, and the bottom half in the right eye")))
						{
							SetRectsByVideoType(overlay, StereoType.StereoTopBottom, DisplayType.Custom);
						}
					}
					EditorGUILayout.EndHorizontal();

				}
				destRectsVisible = EditorGUILayout.Foldout(destRectsVisible, new GUIContent("Destination Rects", "What portion of the destination texture that the source will be rendered into."));
				if (destRectsVisible)
				{

					var mat = DestRectMaterial;

					if (mat != null)
					{
						Rect drawRect = EditorGUILayout.GetControlRect(GUILayout.Height(128 + 8));
						mat.SetVector("_SrcRectLeft", new Vector4(Mathf.Max(0.0f, overlay.srcRectLeft.x), Mathf.Max(0.0f, overlay.srcRectLeft.y), Mathf.Min(1.0f - overlay.srcRectLeft.x, overlay.srcRectLeft.width), Mathf.Min(1.0f - overlay.srcRectLeft.y, overlay.srcRectLeft.height)));
						mat.SetVector("_SrcRectRight", new Vector4(Mathf.Max(0.0f, overlay.srcRectRight.x), Mathf.Max(0.0f, overlay.srcRectRight.y), Mathf.Min(1.0f - overlay.srcRectRight.x, overlay.srcRectRight.width), Mathf.Min(1.0f - overlay.srcRectRight.y, overlay.srcRectRight.height)));
						mat.SetVector("_DestRectLeft", new Vector4(Mathf.Max(0.0f, overlay.destRectLeft.x), Mathf.Max(0.0f, overlay.destRectLeft.y), Mathf.Min(1.0f - overlay.destRectLeft.x, overlay.destRectLeft.width), Mathf.Min(1.0f - overlay.destRectLeft.y, overlay.destRectLeft.height)));
						mat.SetVector("_DestRectRight", new Vector4(Mathf.Max(0.0f, overlay.destRectRight.x), Mathf.Max(0.0f, overlay.destRectRight.y), Mathf.Min(1.0f - overlay.destRectRight.x, overlay.destRectRight.width), Mathf.Min(1.0f - overlay.destRectRight.y, overlay.destRectRight.height)));
						mat.SetColor("_BackgroundColor", EditorGUIUtility.isProSkin ? (Color)new Color32(56, 56, 56, 255) : (Color)new Color32(194, 194, 194, 255));

						var drawRectCentered = new Rect(drawRect.x + drawRect.width / 2 - 128 - 16 - 4, drawRect.y, 256 + 32 + 8, drawRect.height);
						// center our draw rect
						EditorGUI.DrawPreviewTexture(drawRectCentered, overlay.textures[0] ?? Texture2D.blackTexture, mat);

						var drawRectInsetLeft = new Rect(drawRectCentered.x + 4, drawRectCentered.y + 4, drawRectCentered.width / 2 - 20, drawRectCentered.height - 8);
						var drawRectInsetRight = new Rect(drawRectCentered.x + drawRectCentered.width / 2 + 16, drawRectCentered.y + 4, drawRectCentered.width / 2 - 20, drawRectCentered.height - 8);
						UpdateRectDragging(drawRectInsetLeft, drawRectInsetRight, TextureRect.DestLeft, TextureRect.DestRight, ref overlay.destRectLeft, ref overlay.destRectRight);

						CreateCursorRects(drawRectInsetLeft, overlay.destRectLeft);
						CreateCursorRects(drawRectInsetRight, overlay.destRectRight);

					}

					var labelControlRect = EditorGUILayout.GetControlRect();
					EditorGUI.LabelField(new Rect(labelControlRect.x, labelControlRect.y, labelControlRect.width / 2, labelControlRect.height), new GUIContent("Left Destination Rect", "The rect in the destination layer the left eye will display to"));
					EditorGUI.LabelField(new Rect(labelControlRect.x + labelControlRect.width / 2, labelControlRect.y, labelControlRect.width / 2, labelControlRect.height), new GUIContent("Right Destination Rect", "The rect in the destination layer the right eye will display to"));

					var rectControlRect = EditorGUILayout.GetControlRect(GUILayout.Height(34));

					overlay.destRectLeft = Clamp01(EditorGUI.RectField(new Rect(rectControlRect.x, rectControlRect.y, rectControlRect.width / 2 - 20, rectControlRect.height), overlay.destRectLeft));
					overlay.destRectRight = Clamp01(EditorGUI.RectField(new Rect(rectControlRect.x + rectControlRect.width / 2, rectControlRect.y, rectControlRect.width / 2 - 20, rectControlRect.height), overlay.destRectRight));


					if (overlay.currentOverlayShape == OVROverlay.OverlayShape.Equirect)
					{
						EditorGUILayout.BeginHorizontal();
						if (GUILayout.Button(new GUIContent("360 Video", "Display the full 360 layer")))
						{
							SetRectsByVideoType(overlay, StereoType.Custom, DisplayType.Full);
						}
						if (GUILayout.Button(new GUIContent("180 Video", "Display the front 180 layer")))
						{
							SetRectsByVideoType(overlay, StereoType.Custom, DisplayType.Half);
						}
						EditorGUILayout.EndHorizontal();
					}
					else
					{
						if (GUILayout.Button(new GUIContent("Reset To Default", "Reset Source Rects to default")))
						{
							SetRectsByVideoType(overlay, StereoType.Custom, DisplayType.Full);
						}
					}
				}
			}
		}
		EditorGUILayout.Separator();
		EditorGUILayout.LabelField("Color Scale", EditorStyles.boldLabel);
		EditorGUILayout.Space();
		overlay.overridePerLayerColorScaleAndOffset = EditorGUILayout.Toggle(new GUIContent("Override Color Scale", "Manually set color scale and offset of this layer, regardless of what the global values are from OVRManager.SetColorScaleAndOffset()."), overlay.overridePerLayerColorScaleAndOffset);
		if (overlay.overridePerLayerColorScaleAndOffset)
		{
			Vector4 colorScale = EditorGUILayout.Vector4Field(new GUIContent("Color Scale", "Scale that the color values for this overlay will be multiplied by."), overlay.colorScale);
			Vector4 colorOffset = EditorGUILayout.Vector4Field(new GUIContent("Color Offset", "Offset that the color values for this overlay will be added to."), overlay.colorOffset);
			overlay.SetPerLayerColorScaleAndOffset(colorScale, colorOffset);
		}

		EditorUtility.SetDirty(overlay);
	}

	private Rect Clamp01(Rect rect)
	{
		rect.x = Mathf.Clamp01(rect.x);
		rect.y = Mathf.Clamp01(rect.y);
		rect.width = Mathf.Clamp01(rect.width);
		rect.height = Mathf.Clamp01(rect.height);
		return rect;
	}

	private bool IsUnitRect(Rect rect)
	{
		return IsRect(rect, 0, 0, 1, 1);
	}

	private bool IsRect(Rect rect, float x, float y, float w, float h)
	{
		return rect.x == x && rect.y == y && rect.width == w && rect.height == h;
	}

	private StereoType GetStereoType(OVROverlay overlay)
	{
		if (overlay.textures[0] != null && overlay.textures[1] != null)
		{
			if (IsUnitRect(overlay.srcRectLeft) && IsUnitRect(overlay.srcRectRight))
			{
				return StereoType.Stereo;
			}
			else
			{
				return StereoType.Custom;
			}
		}
		else if (overlay.textures[0] != null)
		{
			if (IsUnitRect(overlay.srcRectLeft) && IsUnitRect(overlay.srcRectRight))
			{
				return StereoType.Mono;
			}
			else if (IsRect(overlay.srcRectLeft, 0, 0, 0.5f, 1f) && IsRect(overlay.srcRectRight, 0.5f, 0, 0.5f, 1f))
			{
				return StereoType.StereoLeftRight;
			}
			else if (IsRect(overlay.srcRectLeft, 0, 0, 1f, 0.5f) && IsRect(overlay.srcRectRight, 0f, 0.5f, 1f, 0.5f))
			{
				return StereoType.StereoTopBottom;
			}
			else
			{
				return StereoType.Custom;
			}
		}
		else
		{
			return StereoType.Mono;
		}
	}

	private void SetRectsByVideoType(OVROverlay overlay, StereoType stereoType, DisplayType displayType)
	{
		Rect srcRectLeft, srcRectRight, destRectLeft, destRectRight;

		switch (displayType)
		{
			case DisplayType.Full:
				destRectLeft = destRectRight = new Rect(0, 0, 1, 1);
				break;

			case DisplayType.Half:
				destRectLeft = destRectRight = new Rect(0.25f, 0, 0.5f, 1);
				break;
			default:
				destRectLeft = overlay.destRectLeft;
				destRectRight = overlay.destRectRight;
				break;
		}

		switch (stereoType)
		{
			case StereoType.Mono:
			case StereoType.Stereo:
				srcRectLeft = srcRectRight = new Rect(0, 0, 1, 1);
				break;

			case StereoType.StereoTopBottom:
				srcRectLeft = new Rect(0, 0, 1, 0.5f);
				srcRectRight = new Rect(0, 0.5f, 1, 0.5f);
				break;

			case StereoType.StereoLeftRight:
				srcRectLeft = new Rect(0, 0, 0.5f, 1);
				srcRectRight = new Rect(0.5f, 0, 0.5f, 1);
				break;
			default:
				srcRectLeft = overlay.srcRectLeft;
				srcRectRight = overlay.srcRectRight;
				break;
		}
		overlay.SetSrcDestRects(srcRectLeft, srcRectRight, destRectLeft, destRectRight);
	}

	private void GetCursorPoints(Rect drawRect, Rect selectRect, out Vector2 leftPos, out Vector2 rightPos, out Vector2 topPos, out Vector2 bottomPos)
	{
		leftPos = new Vector2(drawRect.x + selectRect.x * drawRect.width, drawRect.y + (selectRect.y + selectRect.height / 2) * drawRect.height);
		rightPos = new Vector2(drawRect.x + (selectRect.x + selectRect.width) * drawRect.width, drawRect.y + (selectRect.y + selectRect.height / 2) * drawRect.height);
		topPos = new Vector2(drawRect.x + (selectRect.x + selectRect.width / 2) * drawRect.width, drawRect.y + (selectRect.y) * drawRect.height);
		bottomPos = new Vector2(drawRect.x + (selectRect.x + selectRect.width / 2) * drawRect.width, drawRect.y + (selectRect.y + selectRect.height) * drawRect.height);
	}

	private void CreateCursorRects(Rect drawRect, Rect selectRect)
	{
		Vector2 leftPos, rightPos, topPos, bottomPos;
		GetCursorPoints(drawRect, selectRect, out leftPos, out rightPos, out topPos, out bottomPos);

		EditorGUIUtility.AddCursorRect(new Rect(leftPos - 5 * Vector2.one, 10 * Vector2.one), MouseCursor.ResizeHorizontal);
		EditorGUIUtility.AddCursorRect(new Rect(rightPos - 5 * Vector2.one, 10 * Vector2.one), MouseCursor.ResizeHorizontal);
		EditorGUIUtility.AddCursorRect(new Rect(topPos - 5 * Vector2.one, 10 * Vector2.one), MouseCursor.ResizeVertical);
		EditorGUIUtility.AddCursorRect(new Rect(bottomPos - 5 * Vector2.one, 10 * Vector2.one), MouseCursor.ResizeVertical);
	}

	private bool IsOverRectControls(Rect drawRect, Vector2 mousePos, Rect selectRect, ref Side side)
	{
		Vector2 leftPos, rightPos, topPos, bottomPos;
		GetCursorPoints(drawRect, selectRect, out leftPos, out rightPos, out topPos, out bottomPos);

		if ((leftPos - mousePos).sqrMagnitude <= 25)
		{
			side = Side.Left;
			return true;
		}
		if ((rightPos - mousePos).sqrMagnitude <= 25)
		{
			side = Side.Right;
			return true;
		}
		if ((topPos - mousePos).sqrMagnitude <= 25)
		{
			side = Side.Top;
			return true;
		}
		if ((bottomPos - mousePos).sqrMagnitude <= 25)
		{
			side = Side.Bottom;
			return true;
		}
		return false;
	}

	private void UpdateRectDragging(Rect drawingRectLeft, Rect drawingRectRight, TextureRect rectLeftType, TextureRect rectRightType, ref Rect rectLeft, ref Rect rectRight)
	{
		if (!Event.current.isMouse || Event.current.button != 0)
		{
			return;
		}

		if (Event.current.type == EventType.MouseUp)
		{
			_DraggingRect = TextureRect.None;
			return;
		}

		Vector2 mousePos = Event.current.mousePosition;
		if (_DraggingRect == TextureRect.None && Event.current.type == EventType.MouseDown)
		{
			if (IsOverRectControls(drawingRectLeft, mousePos, rectLeft, ref _DraggingSide))
			{
				_DraggingRect = rectLeftType;
			}
			if (_DraggingRect == TextureRect.None || Event.current.shift)
			{
				if (IsOverRectControls(drawingRectRight, mousePos, rectRight, ref _DraggingSide))
				{
					_DraggingRect = rectRightType;
				}
			}
		}

		if (_DraggingRect == rectLeftType)
		{
			SetRectSideValue(drawingRectLeft, mousePos, _DraggingSide, ref rectLeft);
		}
		if (_DraggingRect == rectRightType)
		{
			SetRectSideValue(drawingRectRight, mousePos, _DraggingSide, ref rectRight);
		}
	}

	private void SetRectSideValue(Rect drawingRect, Vector2 mousePos, Side side, ref Rect rect)
	{
		// quantize to 1/32
		float x = Mathf.Clamp01(Mathf.Round(((mousePos.x - drawingRect.x) / drawingRect.width) * 32) / 32.0f);
		float y = Mathf.Clamp01(Mathf.Round(((mousePos.y - drawingRect.y) / drawingRect.height) * 32) / 32.0f);

		switch (side)
		{
			case Side.Left:
				float xMax = rect.xMax;
				rect.x = Mathf.Min(x, xMax);
				rect.width = xMax - rect.x;
				break;
			case Side.Right:
				rect.width = Mathf.Max(0, x - rect.x);
				break;
			case Side.Top:
				float yMax = rect.yMax;
				rect.y = Mathf.Min(y, yMax);
				rect.height = yMax - rect.y;
				break;
			case Side.Bottom:
				rect.height = Mathf.Max(0, y - rect.y);
				break;
		}
	}
}
