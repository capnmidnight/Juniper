public class OVRSandwichComposition
{
	// deprecated since SDK 1.41
}
