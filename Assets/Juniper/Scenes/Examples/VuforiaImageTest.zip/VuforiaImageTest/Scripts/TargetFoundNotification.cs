#if VUFORIA
using System;
using UnityEngine;
using UnityEngine.Events;
using Vuforia;

[Serializable]
public class TargetFoundEvent : UnityEvent<Transform>
{
}

public class TargetFoundNotification : MonoBehaviour, Vuforia.ITrackableEventHandler
{
    public TargetFoundEvent TargetFound;

    public void OnTrackableStateChanged(TrackableBehaviour.Status previousStatus, TrackableBehaviour.Status newStatus)
    {
        if(previousStatus != newStatus && newStatus == TrackableBehaviour.Status.DETECTED)
        {
            TargetFound?.Invoke(transform);
        }
    }
}
#endif
